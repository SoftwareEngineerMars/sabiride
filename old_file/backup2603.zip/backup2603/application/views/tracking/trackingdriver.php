<!-- BEGIN: Content-->

<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-body">

            <!-- gmaps Examples section start -->
            <section id="gmaps-basic-maps">
                <!-- Basic Map -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Tracking Driver</h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div id="map" style="height: 800px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- end of maps tracking -->
        </div>
    </div>
</div>

<!-- END: Content-->