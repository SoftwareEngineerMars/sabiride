

$(document).ready(function () {
  "use strict";
  // print invoice with button
  $(".btn-print").on('click',function () {
    window.print();
  });
});
